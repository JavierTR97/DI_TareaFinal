
package controller;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;
import model.Perro;
import model.Voluntario;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InformeGenerator {

    public static void generarInformePerros(List<Perro> listaPerros) {
        try {
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(listaPerros);
            Map<String, Object> parametros = new HashMap<>();
            parametros.put("LOGO", InformeGenerator.class.getResourceAsStream("/perrete.png"));
            parametros.put("TITULO", "Informe Perros");

            JasperReport report = JasperCompileManager.compileReport(
                    InformeGenerator.class.getResourceAsStream("/informes/informe_perros.jrxml"));
            JasperPrint print = JasperFillManager.fillReport(report, parametros, dataSource);

            // Mostrar en pantalla
            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setTitle("Informe Perros");
            viewer.setVisible(true);

            // Guardar como PDF
            JasperExportManager.exportReportToPdfFile(print, "InformePerros.pdf");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void generarInformeVoluntarios(List<Voluntario> listaVoluntarios) {
        try {
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(listaVoluntarios);
            Map<String, Object> parametros = new HashMap<>();
            parametros.put("LOGO", InformeGenerator.class.getResourceAsStream("/perrete.png"));
            parametros.put("TITULO", "Informe Voluntarios");

            JasperReport report = JasperCompileManager.compileReport(
                    InformeGenerator.class.getResourceAsStream("/informes/informe_voluntarios.jrxml"));
            JasperPrint print = JasperFillManager.fillReport(report, parametros, dataSource);

            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setTitle("Informe Voluntarios");
            viewer.setVisible(true);

            JasperExportManager.exportReportToPdfFile(print, "InformeVoluntarios.pdf");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
