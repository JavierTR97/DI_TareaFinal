package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainController {

    private InformePerrosController controllerPerros;
    private Scene escenaPerros;

    @FXML
    private void abrirInformePerros(ActionEvent e) {
        abrirVentana("/view/InformePerros.fxml", "Informe Perros");
    }

    @FXML
    private void abrirInformeVoluntarios(ActionEvent e) {
        abrirVentana("/view/InformeVoluntarios.fxml", "Informe Voluntarios");
    }

    @FXML
    public void salirApp(ActionEvent actionEvent) {
        System.exit(0);
    }

    private void abrirVentana(String rutaFXML, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Scene scene = new Scene(loader.load());
            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
