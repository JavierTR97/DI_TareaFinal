
package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Perro;

public class InformePerrosController {

    @FXML private TableView<Perro> tablePerros;
    @FXML private TableColumn<Perro, String> colNombre;
    @FXML private TableColumn<Perro, Integer> colEdad;
    @FXML private TableColumn<Perro, String> colRaza;
    @FXML private Button btnAnadir;
    @FXML private Button btnModificar;
    @FXML private Button btnEliminar;
    @FXML private Button btnInforme;

    @FXML
    public final ObservableList<Perro> listaPerros = FXCollections.observableArrayList(
            new Perro("Fido", 3,"chihuaha"),
            new Perro("Luna", 5,"dogo"),
            new Perro("Max", 2,"mastin")
    );

    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));
        colRaza.setCellValueFactory(new PropertyValueFactory<>("raza"));
        tablePerros.setItems(listaPerros);

        btnAnadir.setOnAction(e -> abrirFormulario(null));

        btnModificar.setOnAction(e -> {
            Perro seleccionado = tablePerros.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                abrirFormulario(seleccionado);
            }
        });

        btnInforme.setOnAction(e -> InformeGenerator.generarInformePerros(listaPerros));

        btnEliminar.setOnAction(e -> {
            Perro seleccionado = tablePerros.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                listaPerros.remove(seleccionado);
            }
        });
    }

    private void abrirFormulario(Perro perro) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/PerroForm.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle(perro == null ? "Añadir Perro" : "Modificar Perro");
            stage.initModality(Modality.APPLICATION_MODAL);

            PerroFormController controller = loader.getController();
            controller.setPerro(perro);

            stage.showAndWait();

            if (controller.isGuardado()) {
                if (perro == null) {
                    listaPerros.add(controller.getPerro());
                }
                tablePerros.refresh();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
