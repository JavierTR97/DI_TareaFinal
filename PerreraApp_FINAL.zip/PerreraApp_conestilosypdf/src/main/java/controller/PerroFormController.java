package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Perro;
import model.Voluntario;

public class PerroFormController {

    @FXML private TextField campoNombre;
    @FXML private TextField campoEdad;
    @FXML private TextField campoRaza;
    @FXML private ComboBox<Voluntario> comboVoluntarios;
    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;

    private Perro perro;
    private boolean guardado = false;

    @FXML
    private void initialize() {
        comboVoluntarios.setItems(InformeVoluntariosController.listaVoluntarios);

        comboVoluntarios.setCellFactory(lv -> new ListCell<Voluntario>() {
            @Override
            protected void updateItem(Voluntario item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });

        comboVoluntarios.setButtonCell(new ListCell<Voluntario>() {
            @Override
            protected void updateItem(Voluntario item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNombre());
            }
        });

        btnGuardar.setOnAction(e -> {
            guardar();
            cerrarVentana();
        });

        btnCancelar.setOnAction(e -> cerrarVentana());
    }

    public void setPerro(Perro perro) {
        this.perro = perro;
        if (perro != null) {
            campoNombre.setText(perro.getNombre());
            campoEdad.setText(String.valueOf(perro.getEdad()));
            campoRaza.setText(perro.getRaza());
            comboVoluntarios.setValue(perro.getVoluntario());
        }
    }

    private void guardar() {
        String nombre = campoNombre.getText();
        int edad = Integer.parseInt(campoEdad.getText());
        String raza = campoRaza.getText();
        Voluntario voluntario = comboVoluntarios.getValue();

        if (perro == null) {
            perro = new Perro(nombre, edad, raza);
        } else {
            perro.setNombre(nombre);
            perro.setEdad(edad);
            perro.setRaza(raza);
        }

        perro.setVoluntario(voluntario);
        guardado = true;
    }

    public Perro getPerro() {
        return perro;
    }

    public boolean isGuardado() {
        return guardado;
    }

    private void cerrarVentana() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
}
