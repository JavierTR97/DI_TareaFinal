
package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Voluntario;
import model.Perro;

import java.util.List;

public class VoluntarioFormController {

    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;
    @FXML private TextField campoNombre;
    @FXML private TextField campoTelefono;
    @FXML private TextField campoEmail;


    private Voluntario voluntario;
    private boolean guardado = false;

    @FXML
    private void initialize() {
        btnGuardar.setOnAction(e -> {
            guardar();
            cerrarVentana();
        });

        btnCancelar.setOnAction(e -> cerrarVentana());
    }

    public void setVoluntario(Voluntario voluntario) {
        this.voluntario = voluntario;
        if (voluntario != null) {
            campoNombre.setText(voluntario.getNombre());
            campoTelefono.setText(voluntario.getTelefono());
            campoEmail.setText(voluntario.getEmail());
        }
    }


    private void guardar() {
        String nombre = campoNombre.getText();
        String telefono = campoTelefono.getText();
        String email = campoEmail.getText();


        if (voluntario == null) {
            voluntario = new Voluntario(nombre, telefono, email);
        } else {
            voluntario.setNombre(nombre);
            voluntario.setTelefono(telefono);
            voluntario.setEmail(email);

        }
        guardado = true;
    }

    public Voluntario getVoluntario() {
        return voluntario;
    }

    public boolean isGuardado() {
        return guardado;
    }

    private void cerrarVentana() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
}
