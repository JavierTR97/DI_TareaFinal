
package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Voluntario;

public class InformeVoluntariosController {

    @FXML private TableView<Voluntario> tableVoluntarios;
    @FXML private TableColumn<Voluntario, String> colNombre;
    @FXML private TableColumn<Voluntario, String> colTelefono;
    @FXML private Button btnAnadir;
    @FXML private Button btnModificar;
    @FXML private Button btnEliminar;
    @FXML private Button btnInforme;

    private final ObservableList<Voluntario> listaVoluntarios = FXCollections.observableArrayList(
            new Voluntario("María Gómez", "611234567","marigomez@email.com"),
            new Voluntario("Pedro Ruiz", "622334455","pedroruiz@email.com"),
            new Voluntario("Lucía Pérez", "633445566", "luciaperez@email.com")
    );

    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        tableVoluntarios.setItems(listaVoluntarios);

        btnAnadir.setOnAction(e -> abrirFormulario(null));

        btnModificar.setOnAction(e -> {
            Voluntario seleccionado = tableVoluntarios.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                abrirFormulario(seleccionado);
            }
        });

        btnInforme.setOnAction(e -> InformeGenerator.generarInformeVoluntarios(listaVoluntarios));

        btnEliminar.setOnAction(e -> {
            Voluntario seleccionado = tableVoluntarios.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                listaVoluntarios.remove(seleccionado);
            }
        });
    }

    private void abrirFormulario(Voluntario voluntario) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/VoluntarioForm.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle(voluntario == null ? "Añadir Voluntario" : "Modificar Voluntario");
            stage.initModality(Modality.APPLICATION_MODAL);

            VoluntarioFormController controller = loader.getController();
            controller.setVoluntario(voluntario);

            stage.showAndWait();

            if (controller.isGuardado()) {
                if (voluntario == null) {
                    listaVoluntarios.add(controller.getVoluntario());
                }
                tableVoluntarios.refresh();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
