package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Voluntario;

public class InformeVoluntariosController {

    @FXML private TableView<Voluntario> tableVoluntarios;
    @FXML private TableColumn<Voluntario, String> colNombre;
    @FXML private TableColumn<Voluntario, String> colTelefono;
    @FXML private Button btnAnadir;
    @FXML private Button btnModificar;
    @FXML private Button btnEliminar;

    private final ObservableList<Voluntario> listaVoluntarios = FXCollections.observableArrayList(
            new Voluntario("María Gómez", "611234567"),
            new Voluntario("Pedro Ruiz", "622334455"),
            new Voluntario("Lucía Pérez", "633445566")
    );

    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("nombre"));
        colTelefono.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("telefono"));

        tableVoluntarios.setItems(listaVoluntarios);

        btnAnadir.setOnAction(e -> abrirVentana("/view/VoluntarioForm.fxml", "Añadir Voluntario"));
        btnModificar.setOnAction(e -> {
            Voluntario seleccionado = tableVoluntarios.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                abrirVentana("/view/VoluntarioForm.fxml", "Modificar Voluntario");
            }
        });
        btnEliminar.setOnAction(e -> {
            Voluntario seleccionado = tableVoluntarios.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                listaVoluntarios.remove(seleccionado);
            }
        });
    }

    private void abrirVentana(String ruta, String titulo) {
        try {
            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource(ruta))));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
