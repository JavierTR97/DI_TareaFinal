package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PerroFormController {

    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;
    @FXML private TextField campoNombre;
    @FXML private TextField campoRaza;

    @FXML
    private void initialize() {
        btnGuardar.setOnAction(e -> {
            guardar();
            System.out.println("Datos del perro guardados (simulado).");
            cerrarVentana();
        });

        btnCancelar.setOnAction(e -> cerrarVentana());
    }

    private void cerrarVentana() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
    @FXML
    private void guardar() {
        String nombre = campoNombre.getText();
        String raza = campoRaza.getText();
        System.out.println("Perro guardado: " + nombre + " - " + raza);
    }
}
