package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Perro;

public class InformePerrosController {

    @FXML private TableView<Perro> tablePerros;
    @FXML private TableColumn<Perro, String> colNombre;
    @FXML private TableColumn<Perro, Integer> colEdad;
    @FXML private Button btnAnadir;
    @FXML private Button btnModificar;
    @FXML private Button btnEliminar;

    @FXML
    public final ObservableList<Perro> listaPerros = FXCollections.observableArrayList(
            new Perro("Fido", 3),
            new Perro("Luna", 5),
            new Perro("Max", 2)
    );

    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));

        tablePerros.setItems(listaPerros);

        btnAnadir.setOnAction(e -> abrirVentana("/view/PerroForm.fxml", "Añadir Perro"));
        btnModificar.setOnAction(e -> {
            Perro seleccionado = tablePerros.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                abrirVentana("/view/PerroForm.fxml", "Modificar Perro");
            }
        });
        btnEliminar.setOnAction(e -> {
            Perro seleccionado = tablePerros.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                listaPerros.remove(seleccionado);
            }
        });
    }

    private void abrirVentana(String ruta, String titulo) {
        try {
            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource(ruta))));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
