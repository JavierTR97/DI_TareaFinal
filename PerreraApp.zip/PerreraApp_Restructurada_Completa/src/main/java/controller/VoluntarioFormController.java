package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class VoluntarioFormController {

    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;

    @FXML
    private void initialize() {
        btnGuardar.setOnAction(e -> {
            System.out.println("Datos del voluntario guardados (simulado).");
            cerrarVentana();
        });

        btnCancelar.setOnAction(e -> cerrarVentana());
    }

    private void cerrarVentana() {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
}
